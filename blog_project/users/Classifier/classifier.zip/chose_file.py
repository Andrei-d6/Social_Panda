import sys
from multiprocessing.connection import Client


def main(path):
    address = ('localhost', 6007)
    conn = Client(address, authkey='epicpass')
    conn.send(path)

    if path == 'close':
        conn.close()
        return

    score = conn.recv()
    print(score)
    conn.close()


if __name__ == '__main__':
    main(sys.argv[1])
