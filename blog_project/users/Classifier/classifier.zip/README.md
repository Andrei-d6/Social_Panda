# raccoon_classifier
A yolo and keras implementation of a classifier that tries to predict if a given image contains a raccoon.
